<?php
    include ("Admin/connect.php");

    $query = "SELECT * FROM shelflocations WHERE Map = 0 ORDER BY ShelfNo ASC";
    $query2 = "SELECT * FROM permstructlocations WHERE Map = 0 ORDER BY StructID ASC";
    $result = mysqli_query($conn, $query)or die(mysqli_error());
    $result2 = mysqli_query($conn, $query2)or die(mysqli_error());

    $i = 0;
    while($row = mysqli_fetch_array($result)){
        $list[] = array(
            'X' => $row['X'],
            'Y' => $row['Y'],
            'Width' => $row['Width'],
            'Height' => $row['Height'],
            'ShelfNo' => $row['ShelfNo'],
            'Map' => $row['Map']
        );
        //if shelf is not missing a value, echo a rectangle element representing the shelf
        if(!in_array("MISSING", $list[$i])) {
            $string = "<rect id =\"" . $list[$i]['ShelfNo'] . "\" width=\"" . $list[$i]['Width'] . "\" height=\"" . $list[$i]['Height'] . "\" x=\"" . $list[$i]['X'] . "\" y=\"" . $list[$i]['Y'] . "\" style=\"fill:rgb(0,0,0);\"/>";
            echo($string);
        }
        $i++;
    }

    $j = 0;
    while($row = mysqli_fetch_array($result2)){
        $list2[] = array(
            'StructID' => $row['StructID'],
            'Type' => $row['Type'],
            'X' => $row['X'],
            'Y' => $row['Y'],
            'Width' => $row['Width'],
            'Height' => $row['Height'],
            'Map' => $row['Map']
        );
        //if shelf is not missing a value, echo a rectangle element representing the shelf
        if(!in_array("MISSING", $list2[$j])) {
            if($list2[$j]['Type'] == 1)
                $string = "<rect class = \"st01\" id =\"" . $list2[$j]['StructID'] . "\" width=\"" . $list2[$j]['Width'] . "\" height=\"" . $list2[$j]['Height'] . "\" x=\"" . $list2[$j]['X'] . "\" y=\"" . $list2[$j]['Y'] . "\"\"/>";
            echo($string);
        }
        $j++;
    }

?>